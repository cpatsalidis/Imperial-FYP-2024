# ReflectiveSystemOfSystems
 
 This is a PhD project on multi-agent self-organising systems, using social influence and learning for collective decision making. 
